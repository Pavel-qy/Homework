#Python RSS-Reader
Pure Python command-line RSS reader.